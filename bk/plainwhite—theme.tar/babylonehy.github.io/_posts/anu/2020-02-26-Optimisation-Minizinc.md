---
layout: post
excerpt_separator: "<!--more-->"
title:  "Minizinc"
date:   2020-02-26 11:57:40
categories: Minizinc, Optimisation
# description: 这是显示在首页的概述，正文内容均会被隐藏。
---
## Materials

* [How can we control the search in a finite domain programming solver](https://people.eng.unimelb.edu.au/pstuckey/COMP90046/lec/s7_search.pdf)

## 2D Packing

* [Packing 打包问题](https://zh.coursera.org/lecture/lisan-youhua-jianmo-gaojiepian/2-4-1-zheng-fang-xing-da-bao-TGOH6)
<!--more-->
