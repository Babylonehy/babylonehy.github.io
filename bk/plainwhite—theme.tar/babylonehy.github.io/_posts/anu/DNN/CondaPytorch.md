conda install pytorch torchvision cudatoolkit=10.0 -c pytorch
torch.cuda.is_available()
